import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  Pressable,
  Platform,
  TextInput,
} from "react-native";
import { useState, useEffect } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { ResizeMode } from "expo-av";
import FormField from "../../components/FormField";
import CustomButton from "../../components/CustomButton";
import { icons } from "../../constants";
import DateTimePicker from "@react-native-community/datetimepicker";
import * as ImagePicker from "expo-image-picker";

const Upload = () => {
  const [uploading, setUploading] = useState(false);

  const [form, setForm] = useState({
    description: "",
    image: null,
    ingredients: [],
  });

  const openPicker = async (selectType) => {
    if (selectType === "image") {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled) {
        setForm({
          ...form,
          image: { uri: result.uri },
        });
      } else {
        setForm({
          ...form,
          image: null,
        });
      }
    }
  };
  const submit = () => {};

  return (
    <SafeAreaView className="bg-primary h-full">
      <ScrollView className="px-4 my-6">
        <Text className="font-yesregular text-5xl text-secondary text-center">
          Upload your photo
        </Text>
        <View className="mt-7 space-y-2">
          <Text className="text-secondary font-avregular text-base">
            Upload Photo
          </Text>
          <TouchableOpacity onPress={() => openPicker("image")}>
            {form.image ? (
              <Image
                source={{ uri: form.image.uri }}
                className="w-full h-64 rounded-[27px]"
                useNativeControls
                resizeMode="cover"
              />
            ) : (
              <View className="w-full h-40 px-4 bg-white rounded-[27px] justify-center items-center flex-row">
                <View className="flex-1 justify-center items-center">
                  <TouchableOpacity className="items-center">
                    <Image source={icons.camera} className="w-6 h-6" />
                    <Text className="font-avitalic text-[18px] text-center">
                      Take a picture
                    </Text>
                  </TouchableOpacity>
                </View>

                <View className="flex-1 justify-center items-center">
                  <TouchableOpacity
                    className="items-center"
                    onPress={() => openPicker("image")}
                  >
                    <Image source={icons.upload} className="w-6 h-6" />
                    <Text className="font-avitalic text-[18px] text-center">
                      Choose from your photos
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </TouchableOpacity>
        </View>
        <Text className="flex-1 text-secondary font-avbold text-base mt-[20px]">
          Description
        </Text>
        <View className="w-full px-4 bg-white rounded-[27px] mt-[7px]">
          <TextInput
            title="Description"
            value={form.description}
            placeholder="Give some extra info..."
            otherStyles="mt-10"
            handleChangeText={(e) => setForm({ ...form, description: e })}
            className="mt-[7px] w-full h-[200px] text-secondary font-avbold text-base"
            multiline={true}
            textAlignVertical="top"
          />
        </View>

        <CustomButton
          title="Submit"
          handlePress={submit}
          containerStyles="mt-7"
          isLoading={uploading}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

export default Upload;
