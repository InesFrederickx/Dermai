import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  FlatList,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import * as ImagePicker from "expo-image-picker";
import { useNavigation } from "@react-navigation/native";
import { storage, account, config, ID } from "../../library/appwrite";
import { useGlobalContext } from "../../context/GlobalProvider";

const Scan = () => {
  const navigation = useNavigation();
  const { setSelectedImage } = useGlobalContext();
  const [images, setImages] = useState([]);
  const [selectedImageUri, setSelectedImageUri] = useState(null);
  const [description, setDescription] = useState("");
  const [userId, setUserId] = useState("");

  useEffect(() => {
    const fetchUser = async () => {
      try {
        // Step 2 & 3: Ensure 'account' is initialized
        if (!account) {
          console.error("Account is not initialized");
          return;
        }
        const user = await account.get();
        setUserId(user.$id);
        fetchImages(user.$id);
      } catch (error) {
        Alert.alert("Error", error.message);
      }
    };

    const fetchImages = async (userId) => {
      try {
        const response = await storage.listFiles(config.storageId, [
          `user:${userId}`,
        ]);
        setImages(response.files);
      } catch (error) {
        Alert.alert("Error", error.message);
      }
    };

    fetchUser();
  }, []);

  const requestCameraPermission = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    return status;
  };

  const takePicture = async () => {
    const permissionStatus = await requestCameraPermission();

    if (permissionStatus !== "granted") {
      alert("Sorry, we need camera permissions to make this work!");
      return;
    }

    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setSelectedImageUri(result.uri); // Update state with taken picture URI
    }
  };

  const selectImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setSelectedImageUri(result.uri); // Update state with selected image URI
    }
  };

  const uploadImage = async () => {
    if (selectedImageUri) {
      setSelectedImage(selectedImageUri);
      navigation.navigate("UploadImage"); // Navigate to UploadImage
    }
  };

  const confirmImage = () => {
    // Perform any validation or additional processing if needed
    // For simplicity, directly navigate to UploadImage
    navigation.navigate("UploadImage");
  };

  const renderItem = ({ item }) => (
    <Image
      source={{
        uri: `https://${config.endpoint}/v1/storage/files/${item.$id}/view?project=${config.projectId}`,
      }}
      style={{ width: 100, height: 100, margin: 5 }}
    />
  );

  return (
    <ScrollView className="bg-primary">
      <SafeAreaView className="h-full">
        <View className="flex-grow min-h-[83vh] px-7 my-5 bg-primary">
          <View className="mt-10">
            <View className="items-center">
              <Text className="font-yesregular text-5xl text-secondary text-center">
                Gallery
              </Text>
            </View>
            <View className="items-center">
              <Text className="font-avlightitalic text-base text-secondary mt-1 text-center">
                Upload photos of your face and track your skin health
              </Text>
            </View>
          </View>
          <View className="flex justify-center items-center h-[75%]">
            {selectedImageUri ? (
              <View style={{ flex: 1, alignItems: "center" }}>
                <Image
                  source={{ uri: selectedImageUri }}
                  style={{ width: 300, height: 300 }}
                />
                <TextInput
                  placeholder="Enter description"
                  value={description}
                  onChangeText={(text) => setDescription(text)}
                  style={{
                    borderWidth: 1,
                    borderColor: "#ccc",
                    width: "80%",
                    marginVertical: 20,
                    padding: 10,
                  }}
                />
                <TouchableOpacity onPress={confirmImage}>
                  <Text>Confirm Image</Text>
                </TouchableOpacity>
              </View>
            ) : images.length === 0 ? (
              <Text className="font-avregular text-secondary text-[24px]">
                You don't have any pictures yet
              </Text>
            ) : (
              <FlatList
                data={images}
                renderItem={renderItem}
                keyExtractor={(item) => item.$id}
                numColumns={3}
              />
            )}
            {!selectedImageUri && (
              <View style={{ flexDirection: "row", marginTop: 20 }}>
                <TouchableOpacity onPress={selectImage}>
                  <Text style={{ marginRight: 20 }}>Choose from library</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={takePicture}>
                  <Text>Take a picture</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};

export default Scan;
