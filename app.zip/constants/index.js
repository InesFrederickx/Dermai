import icons from "./icons";
import images from "./images";
import icons_animated from "./icons_animated";

export { icons, images, icons_animated };
